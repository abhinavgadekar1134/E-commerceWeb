-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2021 at 02:22 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_shopee`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `Last_name` varchar(256) NOT NULL,
  `Email` varchar(256) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Date Added` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Name`, `Last_name`, `Email`, `Password`, `Date Added`) VALUES
(1, 'Abhinav', 'Gadekar', 'abhinav123@gmail.com', 'Abhi', '2021-09-04');

-- --------------------------------------------------------

--
-- Table structure for table `laptops`
--

CREATE TABLE `laptops` (
  `id` int(255) NOT NULL,
  `Laptop_name` varchar(256) NOT NULL,
  `Laptop_company` varchar(256) NOT NULL,
  `Laptop_description` varchar(256) NOT NULL,
  `Price` varchar(256) NOT NULL,
  `Quantity` varchar(256) NOT NULL,
  `Images` varchar(256) NOT NULL,
  `Date_added` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `laptops`
--

INSERT INTO `laptops` (`id`, `Laptop_name`, `Laptop_company`, `Laptop_description`, `Price`, `Quantity`, `Images`, `Date_added`) VALUES
(1, 'Inspiron 3511', 'DELL', 'Dell 15 (2021) i5-1135G7 Laptop,8Gb RAM,1TB HDD + 256Gb SSD,15.6\" (39.62 cms) FHD Display, Win 10 + MS Office,Nvidia 2GB MX350 Graphics,Backlit KB, Platinum Silver Color (Inspiron 3511, D560505WIN9S)', '70590', '80', 'upload/136.jpg', '2021-09-11'),
(2, 'Dell Inspiron 3501 ', 'DELL', 'Dell Inspiron 3501 15.6-inch FHD Laptop (11th Gen Core i5-1135G7/8GB/1TB + 256GB SSD/Windows 10 + MS Office 2019/Backlit KB), Soft Mint', '70490', '100', 'upload/781.jpg', '2021-09-11'),
(3, 'Dell Inspiron 5518 ', 'DELL', 'Dell Inspiron 5518 15.6-inch FHD Laptop (11th Gen Core i5-11300H/8GB RAM/512GB SSD/2GB NVIDIA MX450 Graphics/Windows 10 + MS Office),Platinum Silver', '79990', '50', 'upload/706.jpg', '2021-09-11'),
(4, 'Dell Inspiron 7415 ', 'DELL', 'Dell Inspiron 7415 14 inch FHD Touch Display 2in1 Laptop (R5 5500U / 8GB / 512GB SSD / Integrated Graphics / Win 10 + MSO / Backlit KB + FPR + Active Pen /Pebble Metal Color) D560470WIN9P', '68990', '20', 'upload/722.jpg', '2021-09-11'),
(5, 'Dell XPS 7390', 'DELL', 'Dell XPS 7390 13.3\" FHD DisplayThin & Light Laptop (10th Gen i5-10210U/ 8GB/ 512 SSD/ Integrated Graphics/ Win 10 + MSO/ FPR + Backlit KB/ Silver) D560025WIN9S', '101300.00', '50', 'upload/982.jpg', '2021-09-11'),
(6, 'Dell XPS 9700', 'DELL', 'Dell XPS 9700 17.0\" 943.18cms) UHD+ Touch Laptop (I7-10750H/16 GB/1TB SSD/Nvidia 4 GB GTX Graphics/ Win 10 + MS Office/ Silver) D560030WIN9S', '255328.00', '50', 'upload/163.jpg', '2021-09-11'),
(7, 'HP 15', 'HP', 'HP 15 (2021) Thin & Light Ryzen 3-3250 Laptop, 8 GB RAM, 1TB HDD + 256GB SSD, 15.6\" (39.2 cms) FHD Screen, Windows 10, MS Office (15s-gr0012AU)', '42599', '20', 'upload/403.jpg', '2021-09-11'),
(8, 'HP Pavilion Gaming 10th', 'HP', 'HP Pavilion Gaming 10th Gen Intel Core i5 Processor 15.6-inch(39.6 cm) FHD Gaming Laptop (8GB/512GB SSD + 32GB Intel Optane/144 Hz/Win10/MS Office/NVIDIA GTX 1650 4GB/Shadow Black), 15-dk1148TX', '65990.00', '50', 'upload/175.jpg', '2021-09-11'),
(9, 'Lenovo IdeaPad Gaming 3', 'LENOVO', 'Lenovo IdeaPad Gaming 3 AMD Ryzen 5 4600H 15.6\" (39.62cms) Full HD IPS Gaming Laptop (8GB/256GB SSD+1TB HDD/Windows 10/NVIDIA GTX 1650 4GB GDDR6/Onyx Black/2.2Kg), 82EY00UBIN + Xbox Game Pass for PC', '71900', '50', 'upload/236.jpg', '2021-09-11'),
(10, 'Lenovo IdeaPad Slim 3', 'LENOVO', 'Lenovo IdeaPad Slim 3 (2021) | AMD Ryzen 5 |14\" FHD IPS |Thin and Light Laptop | 4-Side Narrow Bezel (8GB/512GB SSD/Win10/MS Office 2019/Backlit KB/Fingerprint Reader/Platinum Grey/1.41Kg), 82KT00BXIN', '65990', '50', 'upload/546.jpg', '2021-09-11'),
(11, 'Lenovo IdeaPad Slim 5', 'LENOVO', 'Lenovo IdeaPad Slim 5 11th Gen Intel Core i5 15.6\" (39.63cm) FHD IPS Thin & Light Laptop (16GB/512GB SSD/Windows 10/MS Office/Nvidia GeForce MX450/Fingerprint Reader/Graphite Grey/1.66Kg), 82FG0148IN', '72460.00', '80', 'upload/818.jpg', '2021-09-11'),
(12, 'Lenovo IdeaPad Slim 5', 'LENOVO', 'Lenovo IdeaPad Slim 5 AMD Ryzen 7 5700U 15.6\" (39.63cm) FHD IPS Thin & Light Laptop (16GB/512GB SSD/Windows 10/MS Office/Backlit Keyboard/Fingerprint Reader/Graphite Grey/1.66Kg), 82LN00A3IN', '66990.00', '30', 'upload/986.jpg', '2021-09-11'),
(13, 'Lenovo ideapadLenovo ThinkPad E15', 'LENOVO', 'Lenovo ThinkPad E15 (2021) Intel Core i5 11th Gen 15.6-inch (39.62 cm)FHD Thin and Light Laptop (8GB RAM/512GB SSD/Windows 10/MS Office/Fingerprint Reader/Black/Aluminium Surface/ 1.7 kg), 20TDS0GA00', '72990.00', '100', 'upload/842.jpg', '2021-09-11'),
(14, 'Lenovo V15 AMD ', 'LENOVO', 'Lenovo V15 AMD 15.6-inch (39.6 cm) FHD Thin and Light Laptop (AMD Athlon Silver 3050 U/ 4GB RAM/ 1TB HDD/ Windows 10 Home/Integrated AMD Radeon Graphics/ Iron Grey/ 1.85 kg), 82C700J0IH', '35090.00', '50', 'upload/147.jpg', '2021-09-11'),
(15, 'Mi Notebook Horizon Edition 14 ', 'Mi', 'Mi Notebook Horizon Edition 14 Intel Core i7-10510U 10th Gen Thin and Light Laptop(8GB/512GB SSD/Windows 10/Nvidia MX350 2GB Graphics/Grey/1.35Kg)(Without Webcam) XMA1904-AF', '57990.00', '10', 'upload/904.jpg', '2021-09-11');

-- --------------------------------------------------------

--
-- Table structure for table `mobiles`
--

CREATE TABLE `mobiles` (
  `id` int(255) NOT NULL,
  `Mobile_name` varchar(256) NOT NULL,
  `Mobile_company` varchar(256) NOT NULL,
  `Mobile_description` varchar(356) NOT NULL,
  `Price` varchar(256) NOT NULL,
  `Quantity` varchar(256) NOT NULL,
  `Images` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobiles`
--

INSERT INTO `mobiles` (`id`, `Mobile_name`, `Mobile_company`, `Mobile_description`, `Price`, `Quantity`, `Images`) VALUES
(1, 'iQOO Z3 5G', 'iQOO', 'iQOO Z3 5G (Cyber Blue, 8GB RAM, 128GB Storage) | Indias First SD 768G 5G Processor | 55W FlashCharge |', '20999', '150', 'upload/775.jpg'),
(2, 'Vivo Y21', 'Vivo ', 'Vivo Y21 (Midnight Blue, 4GB RAM, 64GB Storage) with No Cost EMI/Additional Exchange Offers', '13990', '100', 'upload/809.jpg'),
(3, 'Samsung Galaxy M31', 'Samsung', 'Samsung Galaxy M31 (Ocean Blue, 8GB RAM, 128GB Storage) 6 Months Free Screen Replacement', '16999', '200', 'upload/432.jpg'),
(4, 'Samsung Galaxy M21 ', 'Samsung  ', 'Samsung Galaxy M21 2021 Edition (Charcoal Black , 4GB RAM, 64GB Storage) | FHD+ sAMOLED ', '12990', '200', 'upload/936.jpg'),
(5, 'Redmi 9A', 'Redmi', 'Redmi 9A (Sea Blue 3GB RAM 32GB Storage)| 2GHz Octa-core Helio G25 Processor | 5000 mAh Battery', '10990', '200', 'upload/926.jpg'),
(6, 'realme narzo 30 ', 'realme', 'realme narzo 30 (Racing Blue, 4GB RAM, 64GB Storage) - MediaTek Helio G95 processor I Full HD+ display', '13399', '200', 'upload/745.jpg'),
(7, 'OPPO A74 5G', 'OPPO', 'OPPO A74 5G (Fantastic Purple,6GB RAM,128GB Storage) - 5G Android Smartphone | 5000 mAh Battery ', '17990', '300', 'upload/577.jpg'),
(8, 'OPPO A31', 'OPPO', 'OPPO A31 (Fantasy White, 6GB RAM, 128GB Storage) with No Cost EMI/Additional Exchange Offers', '12490', '300', 'upload/775.jpg'),
(9, 'OnePlus Nord CE', 'OnePlus ', 'OnePlus Nord CE 5G (Blue Void, 8GB RAM, 128GB Storage)', '25999', '500', 'upload/516.jpg'),
(10, 'OnePlus Nord 2 5G', 'OnePlus', 'OnePlus Nord 2 5G (Gray Sierra, 8GB RAM, 128GB Storage)', '30999', '100', 'upload/566.jpg'),
(11, 'Apple iPhone', 'Apple ', 'New Apple iPhone 12 Pro (128GB) - Pacific Blue', '100900', '30', 'upload/302.jpg'),
(12, 'Apple iPhone 12', 'Apple', 'New Apple iPhone 12 Mini (64GB) - Blue', '69990', '40', 'upload/827.jpg'),
(13, ' Apple iPhone 11 ', ' Apple', 'New Apple iPhone 11 (64GB) - White', '52990', '100', 'upload/186.jpg'),
(14, 'Mi 11X Pro 5G ', 'Mi', 'Mi 11X Pro 5G (Cosmic Black, 8GB RAM, 128GB Storage) | Snapdragon 888 | 108MP Camera', '29990', '100', 'upload/920.jpg'),
(15, 'iQOO Z3 5G', 'iQOO', 'iQOO Z3 5G (Cyber Blue, 6GB RAM, 128GB Storage) | Indias First SD 768G 5G Processor | 55W FlashCharge |', '19990', '300', 'upload/344.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `Product_name` varchar(255) NOT NULL,
  `Product_description` varchar(256) NOT NULL,
  `Product_image` varchar(256) NOT NULL,
  `Product_price` varchar(256) NOT NULL,
  `Quantity` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `Product_name`, `Product_description`, `Product_image`, `Product_price`, `Quantity`) VALUES
(1, 'Mi Notebook Horizon Edition 14 ', 'Mi Notebook Horizon Edition 14 Intel Core i7-10510U 10th Gen Thin and Light Laptop(8GB/512GB SSD/Windows 10/Nvidia MX350 2GB Graphics/Grey/1.35Kg)(Without Webcam) XMA1904-AF', 'upload/904.jpg', '57990.00', '2'),
(8, 'realme narzo 30 ', 'realme narzo 30 (Racing Blue, 4GB RAM, 64GB Storage) - MediaTek Helio G95 processor I Full HD+ display', 'upload/745.jpg', '13399', '3'),
(0, 'Mi 11X Pro 5G ', 'Mi 11X Pro 5G (Cosmic Black, 8GB RAM, 128GB Storage) | Snapdragon 888 | 108MP Camera', 'upload/920.jpg', '29990', '1'),
(10, 'OnePlus Nord 2 5G', 'OnePlus Nord 2 5G (Gray Sierra, 8GB RAM, 128GB Storage)', 'upload/566.jpg', '30999', '1'),
(10, 'realme narzo 30 ', 'realme narzo 30 (Racing Blue, 4GB RAM, 64GB Storage) - MediaTek Helio G95 processor I Full HD+ display', 'upload/745.jpg', '13399', '1'),
(11, 'Mi 11X Pro 5G ', 'Mi 11X Pro 5G (Cosmic Black, 8GB RAM, 128GB Storage) | Snapdragon 888 | 108MP Camera', 'upload/920.jpg', '29990', '1'),
(13, ' Apple iPhone 11 ', 'New Apple iPhone 11 (64GB) - White', 'upload/186.jpg', '52990', '1'),
(15, ' Apple iPhone 11 ', 'New Apple iPhone 11 (64GB) - White', 'upload/186.jpg', '52990', '1'),
(16, ' Apple iPhone 11 ', 'New Apple iPhone 11 (64GB) - White', 'upload/186.jpg', '52990', '1'),
(17, ' Apple iPhone 11 ', 'New Apple iPhone 11 (64GB) - White', 'upload/186.jpg', '52990', '1');

-- --------------------------------------------------------

--
-- Table structure for table `order_manager`
--

CREATE TABLE `order_manager` (
  `Order_id` int(255) NOT NULL,
  `Full_name` varchar(256) NOT NULL,
  `Phone_no` varchar(256) NOT NULL,
  `Address` varchar(256) NOT NULL,
  `Pay_mode` varchar(256) NOT NULL,
  `Total_items` varchar(255) NOT NULL,
  `Date_Ordered` date NOT NULL DEFAULT current_timestamp(),
  `Time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_manager`
--

INSERT INTO `order_manager` (`Order_id`, `Full_name`, `Phone_no`, `Address`, `Pay_mode`, `Total_items`, `Date_Ordered`, `Time`) VALUES
(1, 'Abhinav Gadekar', '8010700592', 'Sangamner,ahamadnagar', 'COD', '1', '2021-09-11', ''),
(8, 'Gadekar', '234324', 'Koshti galli near city police station ,Sangamner', 'COD', '1', '2021-09-19', ''),
(11, 'Gadekar', '342', 'Koshti galli near city police station ,Sangamner', 'UPI', '1', '2021-12-31', ''),
(13, 'Gadekar', '42', 'Koshti galli near city police station ,Sangamner', 'COD', '1', '2021-12-31', ''),
(15, 'Gadekar', '3', 'Koshti galli near city police station ,Sangamner', 'COD', '1', '2021-12-31', '<?php time() ?>'),
(16, 'Gadekar', '111', 'Koshti galli near city police station ,Sangamner', 'COD', '1', '2021-12-31', '1640956326'),
(17, 'Gadekar', '55', 'Koshti galli near city police station ,Sangamner', 'COD', '1', '2021-12-31', '02:18 pm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laptops`
--
ALTER TABLE `laptops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobiles`
--
ALTER TABLE `mobiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_manager`
--
ALTER TABLE `order_manager`
  ADD PRIMARY KEY (`Order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `laptops`
--
ALTER TABLE `laptops`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `mobiles`
--
ALTER TABLE `mobiles`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order_manager`
--
ALTER TABLE `order_manager`
  MODIFY `Order_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
